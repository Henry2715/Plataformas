package com.proyecto.crud;

import java.sql.*;
import java.util.*;

public class UsuarioDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/bienestar_universitario";
    private String jdbcUser = "root";
    private String jdbcPassword = "";

    private static final String INSERT_SQL = "INSERT INTO usuarios (nombre_completo, correo_electronico) VALUES (?, ?)";
    private static final String SELECT_ALL_SQL = "SELECT * FROM usuarios";
    private static final String SELECT_BY_ID = "SELECT * FROM usuarios WHERE id = ?";
    private static final String UPDATE_SQL = "UPDATE usuarios SET nombre_completo = ?, correo_electronico = ? WHERE id = ?";
    private static final String DELETE_SQL = "DELETE FROM usuarios WHERE id = ?";

    protected Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPassword);
    }

    public void insertarUsuario(Usuario usuario) throws SQLException {
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(INSERT_SQL)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setString(2, usuario.getCorreoElectronico());
            stmt.executeUpdate();
        }
    }

    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(SELECT_ALL_SQL)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usuarios.add(new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre_completo"),
                    rs.getString("correo_electronico")
                ));
            }
        }
        return usuarios;
    }

    public Usuario obtenerPorId(int id) throws SQLException {
        Usuario usuario = null;
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(SELECT_BY_ID)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre_completo"),
                    rs.getString("correo_electronico")
                );
            }
        }
        return usuario;
    }

    public void actualizarUsuario(Usuario usuario) throws SQLException {
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(UPDATE_SQL)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setString(2, usuario.getCorreoElectronico());
            stmt.setInt(3, usuario.getId());
            stmt.executeUpdate();
        }
    }

    public void eliminarUsuario(int id) throws SQLException {
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(DELETE_SQL)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
